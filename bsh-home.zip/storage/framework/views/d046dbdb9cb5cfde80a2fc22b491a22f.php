

<?php $__env->startSection('contenido'); ?>
    <div class="max-w-lg mx-auto mt-10">
        <form action="<?php echo e(route('enviarCorreo')); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            <label class="block">
                <span class="text-gray-700">Gama de interés (obligatorio)</span>
                <select name="gama_de_interes[]" multiple class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                    <option value="Sellos hidráulicos">Sellos hidráulicos</option>
                    <option value="Bombas y sellos mecánicos">Bombas y sellos mecánicos</option>
                    <option value="Turcite B Slydway">Turcite B Slydway</option>
                    <option value="Mantenimiento y maquinados">Mantenimiento y maquinados</option>
                    <option value="Capacitación y consultoría">Capacitación y consultoría</option>
                </select>
            </label>

            <label class="block">
                <span class="text-gray-700">Nombre (obligatorio)</span>
                <input type="text" name="nombre" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
            </label>

            <label class="block">
                <span class="text-gray-700">Correo electrónico (obligatorio)</span>
                <input type="email" name="email" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
            </label>

            <label class="block">
                <span class="text-gray-700">Número de teléfono (obligatorio)</span>
                <input type="tel" name="telefono" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
            </label>

            <label class="block">
                <span class="text-gray-700">Nombre de la empresa (obligatorio)</span>
                <input type="text" name="empresa" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
            </label>

            <label class="block">
                <span class="text-gray-700">Mensaje (obligatorio)</span>
                <textarea name="mensaje" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"></textarea>
            </label>

            <button type="submit" class="w-full px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-600">Enviar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lupit\Documents\bsh-home\resources\views/formulario.blade.php ENDPATH**/ ?>