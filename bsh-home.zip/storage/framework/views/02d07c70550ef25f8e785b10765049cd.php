<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo mensaje de contacto</title>
</head>
<body>
    <h2>Nuevo mensaje de contacto</h2>
    <p><strong>Gama de interés:</strong> <?php echo e(implode(', ', $datos['gama_de_interes'])); ?></p>
    <p><strong>Nombre:</strong> <?php echo e($datos['nombre']); ?></p>
    <p><strong>Correo electrónico:</strong> <?php echo e($datos['email']); ?></p>
    <p><strong>Número de teléfono:</strong> <?php echo e($datos['telefono']); ?></p>
    <p><strong>Nombre de la empresa:</strong> <?php echo e($datos['empresa']); ?></p>
    <p><strong>Mensaje:</strong> <?php echo e($datos['mensaje']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\Lupit\Documents\bsh-home\resources\views/emails/contacto.blade.php ENDPATH**/ ?>